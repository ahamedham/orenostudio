<?php
/* =====================================================
   ØRENO — SMTP Configuration
   DO NOT commit this file. See .gitignore.
===================================================== */
define('SMTP_HOST', 'mail.oreno.lk');
define('SMTP_PORT', 465);
define('SMTP_USER', 'contact@oreno.lk');
define('SMTP_PASS', 'Ore@2026#');
define('SMTP_FROM', 'ØRENO Studio');
define('MAIL_TO',   'contact@oreno.lk');
