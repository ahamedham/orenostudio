<?php
/* =====================================================
   ØRENO — send-mail.php
   Unified email handler: contact | inquiry | proposal
   No external dependencies — pure PHP SMTP over SSL.
===================================================== */

require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: https://oreno.lk');
header('Access-Control-Allow-Methods: POST');

/* ── Only accept POST ── */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

/* ── Sanitize helpers ── */
function clean(string $v): string {
    return htmlspecialchars(strip_tags(trim($v)), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function require_field(string $v, string $label): void {
    if ($v === '') {
        echo json_encode(['ok' => false, 'error' => $label . ' is required']);
        exit;
    }
}

/* ── Read common fields ── */
$type  = clean($_POST['type']  ?? '');
$name  = clean($_POST['name']  ?? '');
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);

require_field($name,  'Name');
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['ok' => false, 'error' => 'Please enter a valid email address']);
    exit;
}

/* ── Build email body per type ── */
switch ($type) {

    case 'contact':
        $msg = clean($_POST['message'] ?? '');
        require_field($msg, 'Message');
        $subject = 'New Message — ' . $name;
        $html    = email_contact($name, $email, $msg);
        break;

    case 'inquiry':
        $vision   = clean($_POST['vision']   ?? '');
        $timeline = clean($_POST['timeline'] ?? '');
        $budget   = clean($_POST['budget']   ?? '');
        require_field($vision, 'Vision');
        $subject = 'New Project Inquiry — ' . $name;
        $html    = email_inquiry($name, $email, $vision, $timeline, $budget);
        break;

    case 'proposal':
        $package = clean($_POST['package'] ?? '');
        $addons  = clean($_POST['addons']  ?? '');
        $total   = clean($_POST['total']   ?? '');
        $body    = clean($_POST['body']    ?? '');
        require_field($package, 'Package');
        $subject = 'Package Enquiry — ' . $name . ' via oreno.lk/packages';
        $html    = email_proposal($name, $email, $package, $addons, $total, $body);
        break;

    default:
        echo json_encode(['ok' => false, 'error' => 'Unknown form type']);
        exit;
}

/* ── Send ── */
try {
    smtp_send(MAIL_TO, 'ØRENO Studio', $subject, $html, $email, $name);
    echo json_encode(['ok' => true]);
} catch (RuntimeException $e) {
    error_log('[ØRENO mailer] ' . $e->getMessage());
    echo json_encode(['ok' => false, 'error' => 'Message could not be delivered. Please try WhatsApp.']);
}
exit;

/* ════════════════════════════════════════════════════
   SMTP implementation (SSL/TLS, port 465)
════════════════════════════════════════════════════ */

function smtp_send(
    string $to, string $to_name, string $subject, string $html,
    string $reply_email = '', string $reply_name = ''
): void {
    $ctx = stream_context_create([
        'ssl' => [
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
        ],
    ]);

    $sock = @stream_socket_client(
        'ssl://' . SMTP_HOST . ':' . SMTP_PORT,
        $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx
    );
    if (!$sock) {
        throw new RuntimeException("SMTP connect failed ({$errno}): {$errstr}");
    }
    stream_set_timeout($sock, 15);

    smtp_expect($sock, 220);                            // greeting
    smtp_cmd($sock, 'EHLO ' . (gethostname() ?: 'localhost'), 250);
    smtp_cmd($sock, 'AUTH LOGIN', 334);
    smtp_cmd($sock, base64_encode(SMTP_USER), 334);
    smtp_cmd($sock, base64_encode(SMTP_PASS), 235);
    smtp_cmd($sock, 'MAIL FROM:<' . SMTP_USER . '>', 250);
    smtp_cmd($sock, 'RCPT TO:<' . $to . '>', 250);
    smtp_cmd($sock, 'DATA', 354);

    /* Build RFC 2822 message */
    $enc_from    = '=?UTF-8?B?' . base64_encode(SMTP_FROM)  . '?=';
    $enc_to      = '=?UTF-8?B?' . base64_encode($to_name)   . '?=';
    $enc_subj    = '=?UTF-8?B?' . base64_encode($subject)   . '?=';
    $enc_body    = chunk_split(base64_encode($html));

    $msg  = "From: {$enc_from} <" . SMTP_USER . ">\r\n";
    $msg .= "To: {$enc_to} <{$to}>\r\n";
    if ($reply_email) {
        $enc_reply = '=?UTF-8?B?' . base64_encode($reply_name) . '?=';
        $msg .= "Reply-To: {$enc_reply} <{$reply_email}>\r\n";
    }
    $msg .= "Subject: {$enc_subj}\r\n";
    $msg .= "Date: " . date('r') . "\r\n";
    $msg .= "Message-ID: <" . time() . rand(1000,9999) . "@oreno.lk>\r\n";
    $msg .= "MIME-Version: 1.0\r\n";
    $msg .= "Content-Type: text/html; charset=UTF-8\r\n";
    $msg .= "Content-Transfer-Encoding: base64\r\n";
    $msg .= "\r\n";
    $msg .= $enc_body;
    $msg .= "\r\n.";

    fwrite($sock, $msg . "\r\n");
    smtp_expect($sock, 250);
    smtp_cmd($sock, 'QUIT', 221);
    fclose($sock);
}

function smtp_cmd($sock, string $cmd, int $expect): string {
    fwrite($sock, $cmd . "\r\n");
    return smtp_expect($sock, $expect);
}

function smtp_expect($sock, int $expected): string {
    $data = '';
    while ($line = fgets($sock, 512)) {
        $data .= $line;
        if (substr($line, 3, 1) === ' ') break;
    }
    $code = (int) substr($data, 0, 3);
    if ($code !== $expected) {
        throw new RuntimeException("SMTP expected {$expected}, got {$code}: " . trim($data));
    }
    return $data;
}

/* ════════════════════════════════════════════════════
   Email HTML templates
════════════════════════════════════════════════════ */

function email_wrap(string $content): string {
    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#080808;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#080808;">
<tr><td align="center" style="padding:40px 20px;">
  <table width="580" cellpadding="0" cellspacing="0" border="0" style="max-width:580px;width:100%;background:#111;border:1px solid rgba(255,255,255,0.09);border-radius:3px;">

    <!-- Header -->
    <tr><td style="padding:26px 36px;border-bottom:1px solid rgba(255,255,255,0.07);">
      <span style="font-size:11px;letter-spacing:0.22em;text-transform:uppercase;color:rgba(245,243,238,0.4);font-family:monospace;">ØRENO STUDIO</span>
    </td></tr>

    <!-- Body -->
    <tr><td style="padding:36px 36px 32px;">{$content}</td></tr>

    <!-- Footer -->
    <tr><td style="padding:18px 36px;border-top:1px solid rgba(255,255,255,0.07);">
      <span style="font-size:11px;color:rgba(245,243,238,0.28);font-family:monospace;">contact@oreno.lk &nbsp;·&nbsp; oreno.lk &nbsp;·&nbsp; Colombo, Sri Lanka</span>
    </td></tr>

  </table>
</td></tr>
</table>
</body></html>
HTML;
}

function field_row(string $label, string $value): string {
    return "
    <tr>
      <td style='padding:11px 0;border-bottom:1px solid rgba(255,255,255,0.06);color:rgba(245,243,238,0.38);font-size:10px;letter-spacing:0.14em;text-transform:uppercase;font-family:monospace;width:120px;vertical-align:top;white-space:nowrap;'>{$label}</td>
      <td style='padding:11px 0 11px 22px;border-bottom:1px solid rgba(255,255,255,0.06);color:rgba(245,243,238,0.88);font-size:14px;line-height:1.65;vertical-align:top;'>{$value}</td>
    </tr>";
}

function email_contact(string $name, string $email, string $message): string {
    $content = "
    <h2 style='margin:0 0 26px;font-size:20px;font-weight:400;color:rgba(245,243,238,0.92);letter-spacing:-0.3px;'>New Message</h2>
    <table width='100%' cellpadding='0' cellspacing='0' border='0'>
      " . field_row('Name',    esc($name))    . "
      " . field_row('Email',   "<a href='mailto:{$email}' style='color:#b8860b;text-decoration:none;'>{$email}</a>") . "
      " . field_row('Message', nl2br(esc($message))) . "
    </table>";
    return email_wrap($content);
}

function email_inquiry(string $name, string $email, string $vision, string $timeline, string $budget): string {
    $content = "
    <h2 style='margin:0 0 26px;font-size:20px;font-weight:400;color:rgba(245,243,238,0.92);letter-spacing:-0.3px;'>New Project Inquiry</h2>
    <table width='100%' cellpadding='0' cellspacing='0' border='0'>
      " . field_row('Name',     esc($name))     . "
      " . field_row('Email',    "<a href='mailto:{$email}' style='color:#b8860b;text-decoration:none;'>{$email}</a>") . "
      " . field_row('Vision',   nl2br(esc($vision)))   . "
      " . field_row('Timeline', esc($timeline)) . "
      " . field_row('Budget',   esc($budget))   . "
    </table>";
    return email_wrap($content);
}

function email_proposal(string $name, string $email, string $package, string $addons, string $total, string $body): string {
    $addon_html = $addons ? nl2br(esc($addons)) : '<span style="color:rgba(245,243,238,0.35);">None selected</span>';
    $content = "
    <h2 style='margin:0 0 26px;font-size:20px;font-weight:400;color:rgba(245,243,238,0.92);letter-spacing:-0.3px;'>Package Enquiry</h2>
    <table width='100%' cellpadding='0' cellspacing='0' border='0'>
      " . field_row('From',      esc($name))  . "
      " . field_row('Email',     "<a href='mailto:{$email}' style='color:#b8860b;text-decoration:none;'>{$email}</a>") . "
      " . field_row('Package',   esc($package)) . "
      " . field_row('Add-ons',   $addon_html) . "
      " . field_row('Est. Total', esc($total)) . "
      " . field_row('Message',   $body ? nl2br(esc($body)) : '<span style="color:rgba(245,243,238,0.35);">No message</span>') . "
    </table>
    <p style='margin:26px 0 0;font-size:12px;color:rgba(245,243,238,0.35);font-family:monospace;'>Sent via oreno.lk/packages</p>";
    return email_wrap($content);
}

function esc(string $v): string {
    return htmlspecialchars($v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
