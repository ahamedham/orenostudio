<?php
/* =====================================================
   ØRENO — SMTP Configuration
   DO NOT commit this file. See .gitignore.
===================================================== */
define('SMTP_HOST', 'mail.oreno.lk');
define('SMTP_PORT', 465);
define('SMTP_USER', 'contact@oreno.lk');
define('SMTP_PASS', 'Ore@2026#');
define('SMTP_FROM', 'ØRENO Studio');
define('MAIL_TO',   'contact@oreno.lk');

/* HMAC secret for email-verification tokens.
   Change this once after deploy; any value ≥ 32 random chars is fine. */
define('VERIFY_SECRET', 'CHANGE-ME-TO-A-RANDOM-32CHAR-STRING-9f2a7c1e');
